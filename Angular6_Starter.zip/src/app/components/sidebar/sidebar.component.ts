import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { WebserviceService } from '../../services/webservice.service';
import { DatatransferService } from '../../services/datatransfer.service';
import { AuthGuard } from '../../services/canactivate.service';
import { FormBuilder, Validators } from '@angular/forms';

declare const $: any;
declare interface RouteInfo {
    path: string;
    title: string;
    icon: string;
    class: string;
}
export const ROUTES: RouteInfo[] = [
    { path: 'home', title: 'Dashboard', icon: 'dashboard', class: '' },
    { path: 'upload', title: 'Upload File', icon: 'bubble_chart', class: '' },
    { path: 'settlement', title: 'Voucher Settlement', icon: 'content_paste', class: '' },
    { path: 'issuereport', title: 'Advance issued report', icon: 'library_books', class: '' },
    { path: '../login', title: 'Logout', icon: 'unarchive', class: 'active-pro' },
];

@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
    menuItems: any[];
    logintype: any;
    feedbackForm: any;
    restrictedUser  = false;
    
    constructor(public AuthGuard: AuthGuard, private Formbuilder: FormBuilder, public makeapi: WebserviceService, public router: Router, private getdata: DatatransferService) {
        /* document.addEventListener('contextmenu', function (e) {
             e.preventDefault();
         });*/

        document.onkeydown = fkey;
        document.onkeypress = fkey
        document.onkeyup = fkey;

        function fkey(e) {
            e = e || window.event;

            if (e.keyCode === 123) {
                return (e.which || e.keyCode) != 123;
            }
            else if ((e.which === 82) && e.ctrlKey) {
                return false;
            }
            else if ((e.which === 83) && e.ctrlKey) {
                return false;
            }
            else if ((e.which === 73) && e.ctrlKey && e.shiftKey) {
                return false;
            }
            else if ((e.ctrlKey) && (e.which === 116)) {
                return false;
            }
        }
        // window.onresize = function()
        // {
        //     if ((window.outerHeight - window.innerHeight) > 100){
        // alert("inspect is open")
        //     }
        // }
        this.feedbackForm = Formbuilder.group({
            "feedback": [null, Validators.compose([Validators.required])],
        });
    }

    private listBUnitsapi = this.getdata.Coreappconstant + 'listBUnits';
    private getUserPrivapi = this.getdata.appconstant + 'getUserPriv';
    private getSuppPrivapi = this.getdata.appconstant + 'getSuppPriv';
    private DICVForgetConfirmPasswordapi = this.getdata.appconstant + 'DICVForgetConfirmPassword';
    private sendFeedbackapi = this.getdata.Coreappconstant + 'sendFeedback';
    private generateIBMSTokenapi = this.getdata.Coreappconstant + 'generateIBMSToken';

    userbuids = []
    restrictUserid= {'shortid':'arulanv'}
    ngOnInit() {
        this.menuItems = ROUTES.filter(menuItem => menuItem);
        this.getallBUnits();
        this.userbuids = this.AuthGuard.userbuids;
        if (this.AuthGuard.userroleid != 1) {
            this.selectbunits(1)
        }
        
        console.log(this.makeapi.userid);
        if(this.makeapi.userid == 'admin'){
            
        }
        
    }

    isMobileMenu() {
        if ($(window).width() > 991) {
            return false;
        }
        return true;
    };

    bUnits: any;
    getallBUnits() {
        let reqdata = ""
        return this.makeapi.method(this.listBUnitsapi, reqdata, "post")
            .subscribe(data => {
                this.bUnits = data;
            },
                Error => {
                });
    }
    userdata: any;
    usercompds = [];
    usermodids = [];
    count = 0;
    selectbunits(id) {
        this.usercompds = [];
        this.usermodids = [];
        if (this.AuthGuard.userroleid == 3) {
            let reqdata = "userid=" + this.makeapi.userid + "&buid=" + id;
            return this.makeapi.method(this.getUserPrivapi, reqdata, "post")
                .subscribe(data => {
                    this.userdata = data;
                    for (var i = 0; i < data.length && data[i].active == 1; i++) {
                        this.usermodids[i] = data[i].modid;
                        this.usercompds[i] = (data[i].modid).toString() + (data[i].compid).toString();
                    }
                    this.usermodids = [1, 2, 3, 4, 5, 6]

                    var encodedString = localStorage.getItem("disc-portal-session");
                    encodedString = encodedString.substring(6);
                    var decodedString = atob(encodedString);
                    var addmodid = JSON.parse(decodedString);

                    addmodid["modids"] = this.usermodids;

                    // Encode the String
                    var stringdata = JSON.stringify(addmodid)
                    var encodeddata = btoa(stringdata);
                    encodeddata = "az-vel" + encodeddata;
                    localStorage.setItem("disc-portal-session", (encodeddata));

                    this.makeapi.usercompds = this.usercompds;

                    for (var j = 1; j <= 6; j++) {
                        if (this.usermodids.indexOf(j) != -1) {
                            $("#outermodule" + j).removeClass("cursornotallowed");
                            $("#innermodule" + j).removeClass("disabled")
                        }
                        else {
                            $("#outermodule" + j).addClass("cursornotallowed");
                            $("#innermodule" + j).addClass("disabled")
                        }
                    }
                    if (this.count != 0) {
                        this.router.navigateByUrl('/dashboard/home');
                    }
                    else {
                        this.count++;
                    }
                },
                    Error => {
                    });
        }
        else if (this.AuthGuard.session().roleid == 4) {
            this.usermodids = [2, 3, 4, 5]
            var encodedString = localStorage.getItem("disc-portal-session");
            encodedString = encodedString.substring(6);
            var decodedString = atob(encodedString);
            var addmodid = JSON.parse(decodedString);

            addmodid["modids"] = this.usermodids;

            // Encode the String
            var stringdata = JSON.stringify(addmodid)
            var encodeddata = btoa(stringdata);
            encodeddata = "az-vel" + encodeddata;
            localStorage.setItem("disc-portal-session", (encodeddata));

            this.makeapi.usercompds = this.usercompds;
            for (var j = 1; j <= 6; j++) {
                if (this.usermodids.indexOf(j) != -1) {
                    $("#outermodule" + j).removeClass("cursornotallowed");
                    $("#innermodule" + j).removeClass("disabled")
                }
                else {
                    $("#outermodule" + j).addClass("cursornotallowed");
                    $("#innermodule" + j).addClass("disabled")
                }
            }


            let reqdata = "teamid=" + this.AuthGuard.teamid
            return this.makeapi.method(this.getSuppPrivapi, reqdata, "post")
                .subscribe(data => {
                    for (var i = 0; i < data.length && data[i].active == 1; i++) {
                        this.usermodids[i] = data[i].modid;
                        this.usercompds[i] = (data[i].modid).toString() + (data[i].compid).toString();
                    }
                    this.usermodids = [1, 2, 3]

                    var encodedString = localStorage.getItem("disc-portal-session");
                    encodedString = encodedString.substring(6);
                    var decodedString = atob(encodedString);
                    var addmodid = JSON.parse(decodedString);

                    addmodid["modids"] = this.usermodids;
                    // Encode the String
                    var stringdata = JSON.stringify(addmodid)
                    var encodeddata = btoa(stringdata);
                    encodeddata = "az-vel" + encodeddata;
                    localStorage.setItem("disc-portal-session", (encodeddata));

                    this.makeapi.usercompds = this.usercompds;
                    for (var j = 1; j <= 6; j++) {
                        if (this.usermodids.indexOf(j) != -1) {
                            $("#outermodule" + j).removeClass("cursornotallowed");
                            $("#innermodule" + j).removeClass("disabled")
                        }
                        else {
                            $("#outermodule" + j).addClass("cursornotallowed");
                            $("#innermodule" + j).addClass("disabled")
                        }
                    }
                    if (this.count != 0) {
                        this.router.navigateByUrl('/dashboard/home');
                    }
                    else {
                        this.count++;
                    }
                },
                    Error => {
                    });
        }
        else if (this.AuthGuard.userroleid == 1 ) {
            var encodedString = localStorage.getItem("disc-portal-session");
            encodedString = encodedString.substring(6);
            var decodedString = atob(encodedString);
            var addmodid = JSON.parse(decodedString);

            addmodid["modids"] = this.usermodids;

            // Encode the String
            var stringdata = JSON.stringify(addmodid)
            var encodeddata = btoa(stringdata);
            encodeddata = "az-vel" + encodeddata;
            localStorage.setItem("disc-portal-session", (encodeddata));
        }
    }
    feedback() {
        $("#feedback").modal("show");
    }
    confirmsubmitfeedback() {
        if (this.feedbackForm.valid == false) {
            this.getdata.showNotification('bottom', 'right', " Feedback is required", "danger");
        }
        else {
            let idvalue;
            if (this.AuthGuard.session().roleid != 4) {
                idvalue = this.AuthGuard.session().shortid
            }
            else {
                idvalue = this.AuthGuard.session().vendorcode
            }

            let reqdata = "username=" + this.AuthGuard.session().name + "&idvalue=" + idvalue + "&feedback=" + this.feedbackForm.value.feedback;

            return this.makeapi.method(this.sendFeedbackapi, reqdata, "post")
                .subscribe(data => {
                    this.getdata.showNotification('bottom', 'right', " Thank you for your feedback..!", "success");
                    $("#feedback").modal("hide");
                },
                    Error => {
                    });

        }
    }
    changepassword() {
        $("#changepassword").modal("show");
    }
    confirmchangepassword() {
        if (this.feedbackForm.valid == false) {
            if (this.AuthGuard.userroleid == 4) {
                this.getdata.showNotification('bottom', 'right', "Email-id is invalid", "danger");
            }
            else {
                this.getdata.showNotification('bottom', 'right', " Shortid is invalid", "danger");
            }
        }
        else {
            this.getdata.showNotification('bottom', 'right', " New password successfully send to your mail-id..!", "success");
            $("#changepassword").modal("hide");
        }
    }

    genIBMSToken() {
        if (this.AuthGuard.session().roleid != 4) {
            return this.makeapi.method(this.generateIBMSTokenapi, this.AuthGuard.session().id, "postjson")
                .subscribe(data => {
                    if ((data.status).toLowerCase() == 'success') {

                        this.AuthGuard.deliverytoken = data.field;
                        localStorage.removeItem('disc-portal-session');
                        localStorage.removeItem('Daim-packagingSession');
                        this.deleteCookie('packcookies');
                        this.deleteCookie('cookies');
                        window.location.href = "https://ibms.bharatbenz.com/ibmslogin?tokenkey=" + data.field
                    }
                    else {
                        localStorage.removeItem('disc-portal-session');
                        localStorage.removeItem('Daim-packagingSession');
                        this.deleteCookie('packcookies');
                        this.deleteCookie('cookies');
                    }
                },
                    Error => {
                    });
        }
    }
    logout() {
        this.deleteCookie('disc-cookies');
        localStorage.removeItem('disc-portal-session');
        localStorage.removeItem('Daim-packagingSession');
        this.router.navigateByUrl('/login');
    }

    deleteCookie(cname) {
        var d = new Date();
        d.setTime(d.getTime() - (3 * 3600000000));
        var expires = "expires=" + d.toUTCString();
        window.document.cookie = cname + "=" + "; " + expires;

    }
    private getPPInfoapi = this.getdata.Coreappconstant + 'getPPInfo/';

    gotoPackaging() {
      var url;
      if (this.AuthGuard.session().roleid == 4) {
        url = this.getPPInfoapi + this.AuthGuard.session().id + '/1'
      }
      else {
        url = this.getPPInfoapi + this.AuthGuard.session().id + '/0'
      }
      return this.makeapi.method(url, "", "getnoload")
        .subscribe(data => {
          console.log(data)
          var str = data.status;
          var status = str.toLowerCase();
          if (status == 'success') {
  
  
            // Encode the String
            var stringdata = JSON.stringify(data)
            // var encodeddata = btoa(stringdata);
            localStorage.setItem("Daim-packagingSession", (stringdata));
  
          }
        },
          Error => {
          });
    }
}
